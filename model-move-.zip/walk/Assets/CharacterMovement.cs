using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour
{
    public Animator animator;  // Reference to the Animator
    public float speed = 2f;   // Movement speed

    void Update()
    {
        // Check for input
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        // Calculate movement direction
        Vector3 movement = new Vector3(horizontal, 0, vertical).normalized;

        // Move the character
        if (movement.magnitude > 0)
        {
            // Set isWalking to true
            animator.SetBool("isWalking", true);

            // Move the character forward
            transform.Translate(movement * speed * Time.deltaTime, Space.World);

            // Rotate character to face movement direction
            Quaternion toRotation = Quaternion.LookRotation(movement, Vector3.up);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, toRotation, 720 * Time.deltaTime);
        }
        else
        {
            // Set isWalking to false
            animator.SetBool("isWalking", false);
        }
    }
}
